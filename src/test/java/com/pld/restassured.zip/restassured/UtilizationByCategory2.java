package com.pld.restassured;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UtilizationByCategory2 {
	
	@Test
	public void verifyTotalheadcount()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldUtilLowUtilizationHC50";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("PldutillowutilizationHC50");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			int totalhc = json.getInt("TOTAL_HC");
			int lowutilhc = json.getInt("LOW_UTIL_HC");
			
			int hcunder50 = json.getInt("HC_UNDER_50");
			
			System.out.println(totalhc);
			System.out.println(lowutilhc);
			
		
			System.out.println(hcunder50);
	}

}
}
