package com.pld.restassured;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DemandOpenPositiontable {
	
	@Test
	public void verifyOpenPositiontable()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldDemandOpPosDetails";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Plddemandopposdetails");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String jrss = json.getString("JRSS");
			int seat_id = json.getInt("SEAT_ID");
			String contractor = json.getString("CONTRACTOR");
			int band = json.optInt("BAND");
			String start_date = json.getString("START_DT");
			String start_date_info = json.getString("START_DT_INFO");
			String end_date = json.getString("END_DT");
			String seat_type = json.getString("SEAT_TYPE");
			String interlock = json.getString("INTERLOCK");
			String client_nm = json.getString("CLIENT_NM");
			BigDecimal wins_odds = json.getBigDecimal("WINS_ODDS");
			String opp_owner = json.getString("OPP_OWNR");
			String opp_id = json.optString("OPP_ID");
			String Cat_nm = json.getString("CAT_NM");
			String Loc = json.getString("LOC");
			String cat_nm_timeframe = json.getString("CAT_NM_TIMEFRAME");
			String Os_Owner_email = json.getString("OS_OWNR_EMAIL");
			
			
			System.out.println(jrss);
			System.out.println(seat_id);
			System.out.println(contractor);
			System.out.println(band);
			System.out.println(start_date);
			System.out.println(start_date_info);
			System.out.println(end_date);
			System.out.println(seat_type);
			System.out.println(interlock);
			System.out.println(client_nm);
			System.out.println(wins_odds);
			System.out.println(opp_owner);
			System.out.println(opp_id);
			System.out.println(Cat_nm);
			System.out.println(Loc);
			System.out.println(cat_nm_timeframe);
			System.out.println(Os_Owner_email);
			
			
			
		
		
	}
	}

}
