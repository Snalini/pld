package com.pld.restassured;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GapSupplyAndDemandAPI {
	
	@Test
	public void verifySupplyAndDemand()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldGapSupplyDemand";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldgapsupplydemand");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Month_Date = json.getString("MONTH_DT");
			int RollOffs_Bench = json.getInt("SUP_RB");
			int ANOBs = json.getInt("SUP_ANOBS");
			int Depart = json.getInt("SUP_DEPART");
			int Total_Qty = json.getInt("SUPP_TOT_QTY");
			int Dem_Comm = json.getInt("DEM_COMM");
			int Dem_Oppty = json.getInt("DEM_OPPTY");
			int Dem_Other = json.getInt("DEM_OTHER");
			int Dem_Tot = json.getInt("DEM_TOT");
			
			System.out.println(Month_Date);
			System.out.println(RollOffs_Bench);
			System.out.println(ANOBs);
			System.out.println(Depart);
			System.out.println(Total_Qty);
			System.out.println(Dem_Comm);
			System.out.println(Dem_Oppty);
			System.out.println(Dem_Other);
			System.out.println(Dem_Tot);
		}
			
			
			
			
	}

}
