package com.pld.restassured;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BandPyramidAPI {
	
	@Test
	public void verifyBandPyramidAPI()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/Menu/viewSubcon-by/MenuItem/?filter%5Bfields%5D%5Blabel%5D=true&filter%5Bfields%5D%5Bvalue%5D=true&filter%5Border%5D=menuItemId";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONArray jsonarray  = new JSONArray(responsebody);
		for(int i=0;i<jsonarray.length();i++)
		{
			JSONObject jsonobject  = jsonarray.getJSONObject(i);
			String value = jsonobject.getString("value");
			//String menucd = jsonobject.getString("menuCd");
			//int menuitemid = jsonobject.getInt("menuItemId");
			String label = jsonobject.getString("label");
			//int id = jsonobject.getInt("id");
			
			System.out.println(value);
			//System.out.println(menucd);
			//System.out.println(menuitemid);
			System.out.println(label);
			//System.out.println(id);
			
			
		}
	}

	@Test
	public void verifyColumnByFilter()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/Menu/column-by/MenuItem/?filter%5Bfields%5D%5Blabel%5D=true&filter%5Bfields%5D%5Bvalue%5D=true&filter%5Border%5D=menuItemId/";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONArray jsonarray  = new JSONArray(responsebody);
		for(int i=0;i<jsonarray.length();i++)
		{
			JSONObject jsonobject  = jsonarray.getJSONObject(i);
			String value = jsonobject.getString("value");
			//String menucd = jsonobject.getString("menuCd");
			//int menuitemid = jsonobject.getInt("menuItemId");
			String label = jsonobject.getString("label");
			//int id = jsonobject.getInt("id");
			
			System.out.println(value);
			//System.out.println(menucd);
			//System.out.println(menuitemid);
			System.out.println(label);
			//System.out.println(id);
		}
		
	}
	
	@Test
	public void verifyRowByFilter()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/Menu/row-by/MenuItem/?filter[fields][label]=true&filter[fields][value]=true&filter[order]=menuItemId/";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONArray jsonarray  = new JSONArray(responsebody);
		for(int i=0;i<jsonarray.length();i++)
		{
			JSONObject jsonobject  = jsonarray.getJSONObject(i);
			String value = jsonobject.getString("value");
			//String menucd = jsonobject.getString("menuCd");
			//int menuitemid = jsonobject.getInt("menuItemId");
			String label = jsonobject.getString("label");
			//int id = jsonobject.getInt("id");
			
			System.out.println(value);
			//System.out.println(menucd);
			//System.out.println(menuitemid);
			System.out.println(label);
			//System.out.println(id);
		}
		
	}
	
	/*@Test
	public void verifyEmployeesTable()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldDemographicsEmployeesTotalOnInit/?flagVal=('Y','N')";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
	}*/
}
