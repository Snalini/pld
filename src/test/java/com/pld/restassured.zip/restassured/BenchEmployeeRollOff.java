package com.pld.restassured;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BenchEmployeeRollOff {
	
	@Test
	public void verifyBenchEmployeeRollOff()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldBenchEmployeeRolloff";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
	   /* JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldbenchemployeerolloff");
				
		
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			System.out.println(json);
			
		
			JSONObject bencharray = new JSONObject(json);
			JSONArray json_bench = bencharray.getJSONArray("benchData");
			System.out.println(json_bench);
			/*
			for(int j=0;j<bencharray.length();j++)
			{
				JSONObject json_bench = bencharray.get
				JSONObject emp_rolloff = json_bench.getJSONObject("Pldbenchemployeerolloff");
				for(int k=0;k<emp_rolloff.length();k++)
				{
					JSONObject json_emprolloff = emp_rolloff.getJSONObject(responsebody);
					String emp_name = json_emprolloff.getString("NAME");
					System.out.println(emp_name);
				}
			}
			
			
			/*JSONArray benchArray = ja_data.getJSONArray();
			for(int j=0;j<benchArray.length();j++)
			{
				JSONObject benchjson = benchArray.getJSONObject(j);
				
				JSONArray empRolloffArray = jsonobj.getJSONArray("Pldbenchemployeerolloff");
				for(int k=0;k<empRolloffArray.length();k++)
				{
					JSONObject emprolloff = empRolloffArray.getJSONObject(k);
					String emp_name = emprolloff.getString("NAME");
					System.out.println(emp_name);
				}
			}*/
	}

}
	

