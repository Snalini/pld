package com.pld.restassured;

import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.testng.annotations.Test;

import com.mongodb.util.JSON;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class QtrEndProjValues {
	
	 JSONTokener jsonStr;
	
	
	@Test
	
	public void getQtrEndProjValue()
	
	{
		
		
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldQtrProjectionUtilization";
		RequestSpecification request  = RestAssured.given();
		Response response  = request.get();
		String responsebody = response.body().asString();
	    System.out.println("Response Body -->" +responsebody );
	    
	   
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldqtrprojectionutilization");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String utiltype = json.getString("UTIL_TYPE");
			String Qtrendproj = json.getString("QTR_END_PROJ");
			String Target = json.getString("TARGET");
			String Delta_target = json.getString("DELTA_TARGET");
			String Delta_YTY = json.getString("DELTA_YTY");
			System.out.println("Util type is "+utiltype);
			System.out.println("QtrEndPrjection value is "+Qtrendproj);
			System.out.println("Target Value is "+Target);
			System.out.println("Delta Target value is "+Delta_target);
			System.out.println("DeltaYTY value is "+Delta_YTY);
			
		}
	    
	   /* JsonPath jsonPathEvaluator = response.jsonPath();
		   
	    Json.Pldqtrprojectionutilization.push({)
		List<String> dropdownvlaue = jsonPathEvaluator.;
		
		System.out.println(dropdownvlaue);
	  /* for(String util:dropdownvlaue )
	    {
		System.out.println("label recieved from Response  " +util);
	    }*/
	    
	    
	    
	 /* JSONTokener jsonString = null;
		JSONObject obj1 = new JSONObject();
		//System.out.println("Qtrproj value"+ Obj1);
		//String name = obj1.getString("Pldqtrprojectionutilization");
	 // JSONObject pldqtrendprojectionutil = obj1.getJSONObject("Pldqtrendprojectionutil");
	    JSONArray array = obj1.getJSONArray("Pldqtrprojectionutilization");
	    System.out.println(array);
	    for(int i=0;i<array.length();i++)
	    {
	    	JSONArray obj2 = array.getJSONArray(i);
	    	System.out.println("UtilType "+obj2.getString(0)+ "Qtrendprojvalue "+obj2.getString(1));
	    			
	    }
	    
	    
	   /* Iterator<String> keys = obj1.keys();
	    
	    while(keys.hasNext())
	    {
	    	String keyValue = (String)keys.next();
	    	obj2 = pldqtrendprojectionutil.getJSONObject(keyValue);
	    	String UtilType = obj2.getString("UTIL_TYPE");
	    	System.out.println(UtilType);
	    }
	    //String UtilType =obj1.getString("UTIL_TYPE");
	   // System.out.println(UtilType);
	  //  Object obj = parser.parse(response);
	
	    /*Pldqtrprojectionutilization[] pldqtrprojectionutilization = response.jsonPath().getObject("Pldqtrprojectionutilization", Pldqtrprojectionutilization[].class);
	
	    for(Pldqtrprojectionutilization qtrprojvalue:pldqtrprojectionutilization)
	   {
		
	   }
	    JSONObject jobj = (JSONObject).parse(inline);*/
		//String jsonPathEvaluator = response.jsonPath().getString("UTIL_TYPE");
	// System.out.println( jsonPathEvaluator.split);
	//	List<Integer> Qtrendprojvalue = jsonPathEvaluator.getList("QTR_END_PROJ");
		//List<Integer> TargetValue = jsonPathEvaluator.getList("TARGET");
		//List<Integer> TargetPtsValue = jsonPathEvaluator.getList("DELTA_TARGET");
		//List<Integer> YTYPtsValue = jsonPathEvaluator.getList("DELTA_YTY");*/
		
		//System.out.println("UtilType received from Response: "+jsonPathEvaluator.get("DELTA_TARGET"));
		
	

}
}
