package com.pld.restassured;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BenchTableFilters {
	
	@Test
	public void verifyBenchTableFilters()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldBenchTablefilters";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		    JSONObject jsonobj = new JSONObject(responsebody);
			JSONArray ja_data = jsonobj.getJSONArray("Pldbenchtablefilters");
			int length  = ja_data.length();
			for(int i=0;i<length;i++)
			{
				JSONObject json = ja_data.getJSONObject(i);
				String Category = json.optString("CATEGORY");
				int BenchShort = json.getInt("BENCH_SORT");
				String Color = json.optString("COLOR");
				
				System.out.println(Category);
				
				System.out.println(Color);
				System.out.println(BenchShort);
				
		}
	}

}
