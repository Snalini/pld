package com.pld.restassured;

import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class LearningTrainingDetailsYTDTableAPI {
	
	@Test
	public void verifyTrainingDetailsYTDTable()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldTrainingThemes";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
	}

	@Test
	public void verifyStudentYTD()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldTrainingStudentDays";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldtrainingstudentdays");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Learning_Type = json.getString("LEARNING_TYPE");
			BigDecimal H1 = json.getBigDecimal("H1");
			BigDecimal total = json.getBigDecimal("TOTAL");
			int sort = json.getInt("SORT");
			
			System.out.println(Learning_Type);
			System.out.println(H1);
			System.out.println(total);
			System.out.println(sort);
			
			
			
		}
	}
	
	@Test
	public void verifyPrescribedCoreCapabilitylearning()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldTrainingCapabilityLearning";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldtrainingcapabilitylearning");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Band = json.getString("BAND");
			BigDecimal Penet_percent = json.getBigDecimal("PENET_PERC");
			BigDecimal YTY = json.getBigDecimal("YTY");
			int sort = json.getInt("SORT");
			
			System.out.println(Band);
			System.out.println(Penet_percent);
			System.out.println(YTY);
			System.out.println(sort);
			
			
			
		}
	}
}
