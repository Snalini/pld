package com.pld.restassured;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UtilLadDistByBand {
	
	@Test
	public void verifyUtilladDistByBand()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldUtilDistByBand";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldutildistbyband");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Segment = json.optString("SEGMENT");
			int Band1to5 = json.getInt("B1_5");
			int Band6 = json.getInt("B6");
			int Band7 = json.getInt("B7"); 
			int Band8 = json.getInt("B8");
			int Band9 = json.getInt("B9");
			int Band10 = json.getInt("B10");
			int Exec = json.getInt("EXEC");
			String color = json.getString("COLOR");
			
			System.out.println(Segment);
			
			System.out.println(Band1to5);
			System.out.println(Band6);
			System.out.println(Band7);
			System.out.println(Band8);
			System.out.println(Band9);
			System.out.println(Band10);
			System.out.println(Exec);
			System.out.println(color);
			
	}

}
}
