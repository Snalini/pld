package com.pld.restassured;

import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class FTEByContractCoadingAPI {
	
	@Test
	public void verifyLabourDistFTE()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldLaborDistFTE";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
	}

	@Test
	public void verifyViewByMenu()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/Menu/viewemployeecontrib-by/MenuItem/?filter[fields][label]=true&filter[fields][value]=true&filter[order]=menuItemId";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONArray jsonarray = new JSONArray(responsebody);
		
		int length  = jsonarray.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = jsonarray.getJSONObject(i);
			String value = json.getString("value");
			//String menucd = jsonobject.getString("menuCd");
			//int menuitemid = jsonobject.getInt("menuItemId");
			String label = json.getString("label");
			//int id = jsonobject.getInt("id");
			
			System.out.println(value);
			//System.out.println(menucd);
			//System.out.println(menuitemid);
			System.out.println(label);
			//System.out.println(id);
			
			
			
		}
	}
	
	@Test
	public void verifyContributionEmployeetableWithoutGrowthPlatform()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldLaborTotalEmpContrib/";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
	}
	
	/*@Test  ----Same as above API
	public void verifyContributionEmployeeTableWithGrowthPlatform()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldLaborTotalEmpContrib/?filter[where][DSHB_BUS_AREA_NM]=Cloud%20Application%20Innovation";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
	}*/
	
	@Test
	public void verifyOfferingCodeBreakdownViewBy()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/Menu/viewbreakdown-by/MenuItem/?filter[fields][label]=true&filter[fields][value]=true&filter[order]=menuItemId";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
JSONArray jsonarray = new JSONArray(responsebody);
		
		int length  = jsonarray.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = jsonarray.getJSONObject(i);
			String value = json.getString("value");
			//String menucd = jsonobject.getString("menuCd");
			//int menuitemid = jsonobject.getInt("menuItemId");
			String label = json.getString("label");
			//int id = jsonobject.getInt("id");
			
			System.out.println(value);
			//System.out.println(menucd);
			//System.out.println(menuitemid);
			System.out.println(label);
			//System.out.println(id);
		}
	}
	
	@Test
	public void verifyOfferingCodeBreakdownChartNoGrowthPlatform()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldOfferingCodeBreakdown/";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
	}
	
	/*@Test---Same API as above
	public void verifyOfferingCodeBreakdownChartWithGrowthPlatform()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldOfferingCodeBreakdown/?filter[where][DSHB_BUS_AREA_NM]=Cloud%20Application%20Innovation";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray jarray = jsonobj.getJSONArray("Pldofferingcodebreakdown");
		int length = jarray.length();
		for(int i=0;i<length;i++)
		{
		JSONObject json = jarray.getJSONObject(i);
		
		JSONArray jarray2 = new JSONArray(json);
	    length  = jarray2.length();
		for(int j=0;j<length;j++)
		{
			JSONObject json1 = jarray2.getJSONObject(i);
			String Segement = json1.getString("SEGMENT");
			System.out.println(Segement);
			
		}
		}
		
		

	}*/
}
