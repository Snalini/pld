package com.pld.restassured;

import java.math.BigDecimal;

import org.apache.poi.hpsf.Decimal;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CareerAPI {
	
	@Test
	public void verifyMonthlyTrendChart()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldPCMonthlyTrend";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldpcmonthlytrend");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Month = json.getString("Month");
			int Band_Avg = json.getInt("BandAvg");
			int Color = json.getInt("color");
			String current = json.getString("Current");
			
			
		}
	}
	
	@Test
	public void verifyAddsAndLosses()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldPCQuarterlyAddsLosses";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldpcquarterlyaddslosses");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Band = json.getString("BAND");
			int net = json.getInt("NET");
			
			
			
		}
	}
	
	@Test
	public void verifyAverageTimeinBand()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldPCAvgTimeInBand";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldpcavgtimeinband");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Band = json.getString("BAND");
			BigDecimal AvgTimeInband = json.getBigDecimal("AVGTIB");
			int guideline = json.optInt("GUIDELINE");
			int band_outliers = json.optInt("BAND_OUTLIERS");
			System.out.println(Band);
			System.out.println(AvgTimeInband);
			System.out.println(guideline);
			System.out.println(band_outliers);
			
			
			
			
		}
	}

}
