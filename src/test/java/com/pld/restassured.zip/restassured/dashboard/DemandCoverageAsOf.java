package com.pld.restassured.dashboard;

import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DemandCoverageAsOf {
	
	@Test
	public void verifyDemandCoverageAsOf()
	{
		RestAssured.baseURI = "http://bldbz173018.bld.dst.ibm.com:9080/api/pldDemandCoverageAsof";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Plddemandcoverageasof");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String TrainingDate = json.getString("TRAINING_DATE");
			System.out.println(TrainingDate);
			
		}
		
	}
	
	@Test
	public void verifyDemandCoverageChart()
	{
		RestAssured.baseURI = "http://bldbz173018.bld.dst.ibm.com:9080/api/pldDemandCoverage";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject json = new JSONObject(responsebody);
		JSONArray ja_data = json.getJSONArray("Plddemandcoverage");
		System.out.println(ja_data);
		int length = ja_data.length();
		System.out.println(length);
		for(int i=0;i<length;i++ )
		{
			JSONObject demandcoverage = ja_data.getJSONObject(i);
			//System.out.println(demandcoverage);
			JSONObject coverage = demandcoverage.getJSONObject("coverage");
			JSONObject deals = demandcoverage.getJSONObject("deals");
			JSONObject tcv = demandcoverage.getJSONObject("tcv");
			BigDecimal deal = coverage.getBigDecimal("DEAL");
			BigDecimal TCV = coverage.getBigDecimal("TCV");
			System.out.println(deal);
			System.out.println(TCV);
			
			/*JSONObject demandcoverage = ja_data.getJSONObject(i);
			JSONObject deals1 = demandcoverage.getJSONObject("tcv");
			System.out.println(deals1);
		/*	BigDecimal No_Plan = deals.getBigDecimal("NO_PLAN");
			BigDecimal With_Plan = deals.getBigDecimal("WITH_PLAN");
			int TOT = deals.getInt("TOT");
			BigDecimal No_Plan_req = deals.getBigDecimal("NO_PLAN_REQD");
			
		System.out.println(No_Plan);
		System.out.println(With_Plan);
		System.out.println(TOT);
		System.out.println(No_Plan_req);*/
			
		}
	}

}
