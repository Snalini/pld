package com.pld.restassured.dashboard;

import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class FTEByContractAPI {
	
	@Test
	public void verifyLabourAsOf()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldLaborDistAsof";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldlabordistasof");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String TrainingDate = json.getString("TRAINING_DATE");
			System.out.println(TrainingDate);
			
		}
	}
	
	@Test
	public void verifyDistributionChart()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldLaborDistDashboardFTE";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldlabordistdashboardfte");
		System.out.println(ja_data);
		int length = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			{
			JSONObject Gp_Grp = json.optJSONObject("GP_GRP_1");
			System.out.println(Gp_Grp);
			//double FTE_perc = Gp_Grp.optDouble("FTE_PERC");
			String Category = Gp_Grp.getString("CATEGORY");
			BigDecimal fte = Gp_Grp.getBigDecimal("FTE");
			String color = Gp_Grp.optString("COLOR");
			String abbrv = Gp_Grp.getString("ABBRV");
			String hc = Gp_Grp.optString("HC");
			//System.out.println(FTE_perc);
			System.out.println(Category);
			System.out.println(fte);
			System.out.println(color);
			System.out.println(abbrv);
			System.out.println(hc);
			
			JSONArray jarray2 = Gp_Grp.getJSONArray("service_lines");
			int length2 =jarray2.length();
			for(int j=0;j<length2;j++)
			{
				JSONObject json2 = jarray2.getJSONObject(j);
				BigDecimal fte_price = json2.getBigDecimal("FTE_PERC");
				String SL_Category = json2.getString("CATEGORY");
				BigDecimal SL_fte = json2.getBigDecimal("FTE");
				//String SL_color = json2.getString("COLOR");
				String SL_abbrv = json2.getString("ABBRV");
				String Sl_hc = json2.optString("HC");
				System.out.println(fte_price);
				System.out.println(SL_Category);
				System.out.println(SL_fte);
				//System.out.println(SL_color);
				System.out.println(SL_abbrv);
				System.out.println(Sl_hc);
				
			}
			}
			
			JSONObject gp_grp2 = json.optJSONObject("GP_GRP_2");
			System.out.println(gp_grp2);
			String grp2_category = gp_grp2.optString("CATEGORY");
			System.out.println(grp2_category);
		}
	}

}
