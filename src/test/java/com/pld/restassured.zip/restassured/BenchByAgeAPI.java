package com.pld.restassured;

import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BenchByAgeAPI {
	
	int TotalHC;
	@Test
	public void verifyBenchByAgedata()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldBenchByAge";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldbenchbyage");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			TotalHC = json.getInt("TOTAL_HC");
			int AgedBenchHC = json.getInt("AGED_BENCH_HC");
			BigDecimal AgedBenchHCpercent = json.getBigDecimal("AGED_BENCH_HC_PERC");
			System.out.println("Total headcount is "+TotalHC);
			System.out.println("Aged Bench HC is "+AgedBenchHC);
			System.out.println("Aged bench HC percent is "+AgedBenchHCpercent);
	}

}
}
