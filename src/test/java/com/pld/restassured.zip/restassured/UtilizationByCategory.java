package com.pld.restassured;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UtilizationByCategory {
	
	@Test
	public void verifyTotalheadCount()
	{
		
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldUtilLowUtilizationTotalHC";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldutillowutilizationtotalhc");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String lowutilcatnm = json.getString("LOW_UTIL_CAT_NM");
			int hcvalue = json.getInt("HC_VALUE");
			String color = json.getString("COLOR");
			int lowutilsort = json.getInt("LOW_UTIL_SORT");
			
			System.out.println(lowutilcatnm);
			System.out.println(hcvalue);
			
			System.out.println(color);
			System.out.println(lowutilsort);
			
	}

}
}
