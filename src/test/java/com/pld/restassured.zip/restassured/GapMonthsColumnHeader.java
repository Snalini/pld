package com.pld.restassured;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GapMonthsColumnHeader {
	
	@Test
	public void verifyMonthsColumnheader()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldGapColumnHeaders";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldcolumnheaders");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Month1 = json.getString("MO1");
			String Month2 = json.getString("MO2");
			String Month3 = json.getString("MO3");
			System.out.println(Month1);
			System.out.println(Month2);
			System.out.println(Month3);
		}
	}

}
