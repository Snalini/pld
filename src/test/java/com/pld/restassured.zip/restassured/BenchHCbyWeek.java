package com.pld.restassured;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BenchHCbyWeek {
	
	
	@Test
	public void verifyBenchHCbyWeekdata()
	{
		RestAssured.baseURI = "http://bldbz173018.cloud.dst.ibm.com:9080/api/pldBenchHCByWeek";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldbenchhcbyweek");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Segment = json.getString("SEGMENT");
			String X_Axis_Weekdate = json.getString("DATE_WEEK");
			int Y_Axis_HeadCount = json.getInt("HC");
			String ThisWeek = json.getString("THIS_WEEK");
			System.out.println(Segment);
			System.out.println(X_Axis_Weekdate);
			System.out.println(Y_Axis_HeadCount);
			System.out.println(ThisWeek);
	}

}
}