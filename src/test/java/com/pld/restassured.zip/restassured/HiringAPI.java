package com.pld.restassured;

import java.math.BigDecimal;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class HiringAPI {
	
	@Test
	public void verifyKeyStaticsTable()
	{
		RestAssured.baseURI = "http://bldbz173018.bld.dst.ibm.com:9080/api/pldHiringKeyStatistics";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
		
		JSONObject jsonobj = new JSONObject(responsebody);
		JSONArray ja_data = jsonobj.getJSONArray("Pldhiringkeystatistics");
		int length  = ja_data.length();
		for(int i=0;i<length;i++)
		{
			JSONObject json = ja_data.getJSONObject(i);
			String Band = json.getString("BAND");
			BigDecimal Accepts = json.getBigDecimal("ACCEPTS");
			BigDecimal Avg_to_Accept = json.getBigDecimal("AVG_TO_ACCEPT");
			BigDecimal Avg_to_Onboard = json.getBigDecimal("AVG_TO_ONBOARD");
			String females = json.optString("FEMALES");
			int sort = json.getInt("SORT");
			
			System.out.println(Band);
			System.out.println(Accepts);
			System.out.println(Avg_to_Accept);
			System.out.println(Avg_to_Onboard);
			System.out.println(females);
			System.out.println(sort);
			
			
			
		}
	}
	
	@Test
	public void verifyRecentJoiners()
	{
		RestAssured.baseURI = "http://bldbz173018.bld.dst.ibm.com:9080/api/pldRecentJoinersList";
		RequestSpecification httpRequest = RestAssured.given();
		Response response = httpRequest.request(Method.GET);
		String responsebody = response.getBody().asString();
		System.out.println(responsebody);
	}

}
